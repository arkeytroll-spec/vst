# Paragon-8

An 8-voice, dual-layer polyphonic synth modeled on the classic late-70s dual-channel polysynths.
VST3 + Standalone, built with JUCE 8.

## Build on Windows
1. Install **Visual Studio 2022** (tick "Desktop development with C++"), **CMake**, and **Git**.
2. Double-click `build_windows.bat` (the first run downloads JUCE and takes a few minutes).
3. Copy `build\Paragon8_artefacts\Release\VST3\Paragon-8.vst3` into
   `C:\Program Files\Common Files\VST3`.
4. In FL Studio: Options > Manage plugins > Find installed plugins, then add Paragon-8.

A standalone app is also built in `build\Paragon8_artefacts\Release\Standalone\`.

## Controls
- Channel I / Channel II: feet, detune, PW + PWM, saw/square/sine/noise, HPF + LPF with resonance,
  IL/AL filter envelope, ADSR amp envelope, level.
- Sub oscillator (6 shapes, delayed fade-in) to pitch/filter/amp, ring mod with attack/decay, stereo chorus.
- Touch: velocity and aftertouch (poly + channel) to brilliance/level/pitch. "Ribbon" = pitch bend range.
- Mod wheel adds vibrato. Double-click any knob to reset it.

## Renaming
Change `PRODUCT_NAME` in `CMakeLists.txt` (and `PLUGIN_CODE` if it should count as a different plugin).
