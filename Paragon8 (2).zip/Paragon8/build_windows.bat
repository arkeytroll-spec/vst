@echo off
REM Builds Paragon-8 (VST3 + Standalone) with Visual Studio 2022.
REM Needs: Visual Studio 2022 (Desktop development with C++), CMake, Git.
cmake -B build -G "Visual Studio 17 2022" -A x64
if errorlevel 1 goto :fail
cmake --build build --config Release
if errorlevel 1 goto :fail
echo.
echo Done! Your plugin is here:
echo   build\Paragon8_artefacts\Release\VST3\Paragon-8.vst3
echo Copy that whole Paragon-8.vst3 folder into:
echo   C:\Program Files\Common Files\VST3
pause
exit /b 0
:fail
echo Build failed - scroll up for the first error.
pause
exit /b 1
