#pragma once
#include <juce_audio_processors/juce_audio_processors.h>

// Plain-float snapshot of every parameter, refreshed once per audio block.
struct ChannelParams
{
    int   feet = 1;                              // 0=16' 1=8' 2=4' 3=2'
    float detune = 0, pw = 0.5f, pwmRate = 1, pwmDepth = 0;
    float saw = 1, square = 0, sine = 0, noise = 0;
    float hpf = 20, hpfRes = 0, lpf = 1800, lpfRes = 0.15f;
    float fIL = 0, fAL = 1, fA = 0.05f, fD = 0.8f, fR = 0.5f, fAmt = 0.45f;
    float aA = 0.01f, aD = 0.6f, aS = 0.85f, aR = 0.5f, level = 1;
};

struct SynthParams
{
    ChannelParams ch[2];
    int   subWave = 0;
    float subRate = 5.5f, subDelay = 0.4f, subVco = 0, subVcf = 0, subVca = 0;
    float ringSpeed = 110, ringDepth = 0, ringAttack = 0.01f, ringDecay = 10;
    float velBril = 0.3f, velLevel = 0.5f, atBril = 0.5f, atLevel = 0.3f, atPitch = 0;
    float bendRange = 2, glide = 0, drift = 0.3f, brilliance = 0, resonance = 0, balance = 0.5f;
};

namespace ParamIDs
{
    inline juce::String ch (int c, const char* name) { return "c" + juce::String (c + 1) + "_" + name; }
}

inline juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout()
{
    using namespace juce;
    AudioProcessorValueTreeState::ParameterLayout layout;

    auto addF = [&] (const String& id, const String& name, float lo, float hi, float def,
                     float centre = -1.0f, const String& unit = {})
    {
        NormalisableRange<float> r (lo, hi);
        if (centre > lo && centre < hi)
            r.setSkewForCentre (centre);
        layout.add (std::make_unique<AudioParameterFloat> (ParameterID { id, 1 }, name, r, def,
                                                           AudioParameterFloatAttributes().withLabel (unit)));
    };
    auto addC = [&] (const String& id, const String& name, const StringArray& choices, int def)
    {
        layout.add (std::make_unique<AudioParameterChoice> (ParameterID { id, 1 }, name, choices, def));
    };

    for (int c = 0; c < 2; ++c)
    {
        const String n = c == 0 ? "I " : "II ";
        addC (ParamIDs::ch (c, "feet"),     n + "Feet",        { "16'", "8'", "4'", "2'" }, 1);
        addF (ParamIDs::ch (c, "detune"),   n + "Detune",      -50.0f, 50.0f, c == 0 ? 0.0f : 7.0f, -1, "ct");
        addF (ParamIDs::ch (c, "pw"),       n + "Pulse Width", 0.05f, 0.95f, 0.5f);
        addF (ParamIDs::ch (c, "pwmRate"),  n + "PWM Speed",   0.05f, 20.0f, 1.0f, 2.0f, "Hz");
        addF (ParamIDs::ch (c, "pwmDepth"), n + "PWM Depth",   0.0f, 1.0f, 0.0f);
        addF (ParamIDs::ch (c, "saw"),      n + "Saw",         0.0f, 1.0f, 1.0f);
        addF (ParamIDs::ch (c, "square"),   n + "Square",      0.0f, 1.0f, c == 0 ? 0.0f : 0.8f);
        addF (ParamIDs::ch (c, "sine"),     n + "Sine",        0.0f, 1.0f, 0.0f);
        addF (ParamIDs::ch (c, "noise"),    n + "Noise",       0.0f, 1.0f, 0.0f);
        addF (ParamIDs::ch (c, "hpf"),      n + "HPF Cutoff",  20.0f, 8000.0f, 20.0f, 300.0f, "Hz");
        addF (ParamIDs::ch (c, "hpfRes"),   n + "HPF Resonance", 0.0f, 1.0f, 0.0f);
        addF (ParamIDs::ch (c, "lpf"),      n + "LPF Cutoff",  30.0f, 18000.0f, 1800.0f, 1200.0f, "Hz");
        addF (ParamIDs::ch (c, "lpfRes"),   n + "LPF Resonance", 0.0f, 1.0f, 0.15f);
        addF (ParamIDs::ch (c, "fIL"),      n + "Filter Initial Level", 0.0f, 1.0f, 0.0f);
        addF (ParamIDs::ch (c, "fAL"),      n + "Filter Attack Level",  0.0f, 1.0f, 1.0f);
        addF (ParamIDs::ch (c, "fA"),       n + "Filter Attack",  0.001f, 10.0f, 0.05f, 0.5f, "s");
        addF (ParamIDs::ch (c, "fD"),       n + "Filter Decay",   0.001f, 10.0f, 0.8f,  0.5f, "s");
        addF (ParamIDs::ch (c, "fR"),       n + "Filter Release", 0.001f, 10.0f, 0.5f,  0.5f, "s");
        addF (ParamIDs::ch (c, "fAmt"),     n + "Filter Env Amount", 0.0f, 1.0f, 0.45f);
        addF (ParamIDs::ch (c, "aA"),       n + "Amp Attack",  0.001f, 10.0f, 0.01f, 0.5f, "s");
        addF (ParamIDs::ch (c, "aD"),       n + "Amp Decay",   0.001f, 10.0f, 0.6f,  0.5f, "s");
        addF (ParamIDs::ch (c, "aS"),       n + "Amp Sustain", 0.0f, 1.0f, 0.85f);
        addF (ParamIDs::ch (c, "aR"),       n + "Amp Release", 0.001f, 10.0f, 0.5f,  0.5f, "s");
        addF (ParamIDs::ch (c, "level"),    n + "Level",       0.0f, 1.0f, c == 0 ? 0.9f : 0.7f);
    }

    addC ("sub_wave",   "Sub Osc Wave", { "Sine", "Square", "Saw Up", "Saw Down", "Random", "Noise" }, 0);
    addF ("sub_rate",   "Sub Osc Speed",   0.05f, 30.0f, 5.5f, 4.0f, "Hz");
    addF ("sub_delay",  "Sub Osc Delay",   0.0f, 5.0f, 0.4f, 1.0f, "s");
    addF ("sub_vco",    "Sub Osc > Pitch", 0.0f, 12.0f, 0.0f, 1.0f, "st");
    addF ("sub_vcf",    "Sub Osc > Filter", 0.0f, 4.0f, 0.0f, -1, "oct");
    addF ("sub_vca",    "Sub Osc > Amp",   0.0f, 1.0f, 0.0f);

    addF ("ring_speed",  "Ring Mod Speed",  0.5f, 2000.0f, 110.0f, 100.0f, "Hz");
    addF ("ring_depth",  "Ring Mod Depth",  0.0f, 1.0f, 0.0f);
    addF ("ring_attack", "Ring Mod Attack", 0.001f, 10.0f, 0.01f, 0.5f, "s");
    addF ("ring_decay",  "Ring Mod Decay",  0.001f, 10.0f, 10.0f, 1.0f, "s");

    addF ("ch_rate",  "Chorus Speed", 0.05f, 6.0f, 0.5f, 1.0f, "Hz");
    addF ("ch_depth", "Chorus Depth", 0.0f, 1.0f, 0.5f);
    addF ("ch_mix",   "Chorus Mix",   0.0f, 1.0f, 0.35f);

    addF ("vel_bril",   "Velocity > Brilliance",   0.0f, 1.0f, 0.3f);
    addF ("vel_level",  "Velocity > Level",        0.0f, 1.0f, 0.5f);
    addF ("at_bril",    "Aftertouch > Brilliance", 0.0f, 1.0f, 0.5f);
    addF ("at_level",   "Aftertouch > Level",      0.0f, 1.0f, 0.3f);
    addF ("at_pitch",   "Aftertouch > Pitch",      -2.0f, 2.0f, 0.0f, -1, "st");
    addF ("bend_range", "Ribbon / Bend Range",     0.0f, 12.0f, 2.0f, -1, "st");
    addF ("glide",      "Portamento",              0.0f, 3.0f, 0.0f, 0.3f, "s");
    addF ("drift",      "Analog Drift",            0.0f, 1.0f, 0.3f);
    addF ("brilliance", "Brilliance",              -1.0f, 1.0f, 0.0f);
    addF ("resonance",  "Resonance",               -1.0f, 1.0f, 0.0f);
    addF ("balance",    "Channel Balance",         0.0f, 1.0f, 0.5f);
    addF ("volume",     "Volume",                  -36.0f, 6.0f, -6.0f, -1, "dB");

    return layout;
}

// Grabs the raw atomics once so the audio thread never looks parameters up by name.
struct ParamPointers
{
    struct Ch
    {
        std::atomic<float> *feet, *detune, *pw, *pwmRate, *pwmDepth, *saw, *square, *sine, *noise,
                           *hpf, *hpfRes, *lpf, *lpfRes, *fIL, *fAL, *fA, *fD, *fR, *fAmt,
                           *aA, *aD, *aS, *aR, *level;
    } ch[2];

    std::atomic<float> *subWave, *subRate, *subDelay, *subVco, *subVcf, *subVca,
                       *ringSpeed, *ringDepth, *ringAttack, *ringDecay,
                       *chRate, *chDepth, *chMix,
                       *velBril, *velLevel, *atBril, *atLevel, *atPitch,
                       *bendRange, *glide, *drift, *brilliance, *resonance, *balance, *volume;

    void init (juce::AudioProcessorValueTreeState& s)
    {
        auto get = [&] (const juce::String& id) { auto* p = s.getRawParameterValue (id); jassert (p != nullptr); return p; };
        for (int c = 0; c < 2; ++c)
        {
            auto& x = ch[c];
            x.feet = get (ParamIDs::ch (c, "feet"));       x.detune = get (ParamIDs::ch (c, "detune"));
            x.pw = get (ParamIDs::ch (c, "pw"));           x.pwmRate = get (ParamIDs::ch (c, "pwmRate"));
            x.pwmDepth = get (ParamIDs::ch (c, "pwmDepth"));
            x.saw = get (ParamIDs::ch (c, "saw"));         x.square = get (ParamIDs::ch (c, "square"));
            x.sine = get (ParamIDs::ch (c, "sine"));       x.noise = get (ParamIDs::ch (c, "noise"));
            x.hpf = get (ParamIDs::ch (c, "hpf"));         x.hpfRes = get (ParamIDs::ch (c, "hpfRes"));
            x.lpf = get (ParamIDs::ch (c, "lpf"));         x.lpfRes = get (ParamIDs::ch (c, "lpfRes"));
            x.fIL = get (ParamIDs::ch (c, "fIL"));         x.fAL = get (ParamIDs::ch (c, "fAL"));
            x.fA = get (ParamIDs::ch (c, "fA"));           x.fD = get (ParamIDs::ch (c, "fD"));
            x.fR = get (ParamIDs::ch (c, "fR"));           x.fAmt = get (ParamIDs::ch (c, "fAmt"));
            x.aA = get (ParamIDs::ch (c, "aA"));           x.aD = get (ParamIDs::ch (c, "aD"));
            x.aS = get (ParamIDs::ch (c, "aS"));           x.aR = get (ParamIDs::ch (c, "aR"));
            x.level = get (ParamIDs::ch (c, "level"));
        }
        subWave = get ("sub_wave");   subRate = get ("sub_rate");   subDelay = get ("sub_delay");
        subVco = get ("sub_vco");     subVcf = get ("sub_vcf");     subVca = get ("sub_vca");
        ringSpeed = get ("ring_speed"); ringDepth = get ("ring_depth");
        ringAttack = get ("ring_attack"); ringDecay = get ("ring_decay");
        chRate = get ("ch_rate");     chDepth = get ("ch_depth");   chMix = get ("ch_mix");
        velBril = get ("vel_bril");   velLevel = get ("vel_level");
        atBril = get ("at_bril");     atLevel = get ("at_level");   atPitch = get ("at_pitch");
        bendRange = get ("bend_range"); glide = get ("glide");      drift = get ("drift");
        brilliance = get ("brilliance"); resonance = get ("resonance");
        balance = get ("balance");    volume = get ("volume");
    }

    void load (SynthParams& p) const
    {
        for (int c = 0; c < 2; ++c)
        {
            auto& s = ch[c];
            auto& d = p.ch[c];
            d.feet = (int) s.feet->load();   d.detune = s.detune->load();
            d.pw = s.pw->load();             d.pwmRate = s.pwmRate->load();   d.pwmDepth = s.pwmDepth->load();
            d.saw = s.saw->load();           d.square = s.square->load();
            d.sine = s.sine->load();         d.noise = s.noise->load();
            d.hpf = s.hpf->load();           d.hpfRes = s.hpfRes->load();
            d.lpf = s.lpf->load();           d.lpfRes = s.lpfRes->load();
            d.fIL = s.fIL->load();           d.fAL = s.fAL->load();
            d.fA = s.fA->load();             d.fD = s.fD->load();   d.fR = s.fR->load();
            d.fAmt = s.fAmt->load();
            d.aA = s.aA->load();             d.aD = s.aD->load();   d.aS = s.aS->load();   d.aR = s.aR->load();
            d.level = s.level->load();
        }
        p.subWave = (int) subWave->load();  p.subRate = subRate->load();  p.subDelay = subDelay->load();
        p.subVco = subVco->load();          p.subVcf = subVcf->load();    p.subVca = subVca->load();
        p.ringSpeed = ringSpeed->load();    p.ringDepth = ringDepth->load();
        p.ringAttack = ringAttack->load();  p.ringDecay = ringDecay->load();
        p.velBril = velBril->load();        p.velLevel = velLevel->load();
        p.atBril = atBril->load();          p.atLevel = atLevel->load();  p.atPitch = atPitch->load();
        p.bendRange = bendRange->load();    p.glide = glide->load();      p.drift = drift->load();
        p.brilliance = brilliance->load();  p.resonance = resonance->load();
        p.balance = balance->load();
    }
};
