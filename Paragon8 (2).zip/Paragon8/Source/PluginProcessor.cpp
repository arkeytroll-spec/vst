#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
    struct Preset
    {
        const char* name;
        std::vector<std::pair<const char*, float>> values;   // anything not listed = default
    };

    const std::vector<Preset>& presets()
    {
        static const std::vector<Preset> list =
        {
            { "Init", {} },

            { "Neon Brass", {
                { "c1_saw", 1 }, { "c1_square", 0 }, { "c2_saw", 1 }, { "c2_square", 0 }, { "c2_detune", 9 },
                { "c1_lpf", 420 }, { "c2_lpf", 460 }, { "c1_lpfRes", 0.25f }, { "c2_lpfRes", 0.25f },
                { "c1_fA", 0.14f }, { "c2_fA", 0.16f }, { "c1_fD", 1.4f }, { "c2_fD", 1.4f },
                { "c1_fAmt", 0.55f }, { "c2_fAmt", 0.55f }, { "c1_fR", 0.8f }, { "c2_fR", 0.8f },
                { "c1_aA", 0.08f }, { "c2_aA", 0.1f }, { "c1_aS", 0.8f }, { "c2_aS", 0.8f },
                { "c1_aR", 1.0f }, { "c2_aR", 1.1f }, { "c2_level", 0.85f },
                { "vel_bril", 0.45f }, { "at_bril", 0.7f }, { "sub_vco", 0.12f }, { "sub_delay", 1.0f },
                { "ch_mix", 0.45f }, { "ch_depth", 0.6f } } },

            { "Rain Pad", {
                { "c1_saw", 0 }, { "c1_square", 0.9f }, { "c1_pw", 0.3f }, { "c1_pwmDepth", 0.45f }, { "c1_pwmRate", 0.7f },
                { "c2_saw", 0.9f }, { "c2_square", 0 }, { "c2_feet", 0 }, { "c2_detune", -7 },
                { "c1_lpf", 900 }, { "c2_lpf", 700 }, { "c1_lpfRes", 0.1f }, { "c2_lpfRes", 0.1f },
                { "c1_fA", 1.6f }, { "c2_fA", 2.0f }, { "c1_fD", 3.0f }, { "c2_fD", 3.0f },
                { "c1_fAmt", 0.3f }, { "c2_fAmt", 0.25f },
                { "c1_aA", 1.3f }, { "c2_aA", 1.6f }, { "c1_aD", 2.0f }, { "c2_aD", 2.0f },
                { "c1_aS", 0.9f }, { "c2_aS", 0.9f }, { "c1_aR", 3.0f }, { "c2_aR", 3.5f },
                { "sub_vco", 0.15f }, { "sub_delay", 1.5f }, { "sub_rate", 5.0f },
                { "ch_mix", 0.65f }, { "ch_depth", 0.75f }, { "ch_rate", 0.35f } } },

            { "Pressure Lead", {
                { "c2_saw", 0 }, { "c2_square", 0.8f }, { "c2_feet", 2 },
                { "c1_lpf", 1500 }, { "c2_lpf", 1500 }, { "c1_lpfRes", 0.45f }, { "c2_lpfRes", 0.35f },
                { "c1_fAmt", 0.35f }, { "c2_fAmt", 0.35f }, { "c1_aR", 0.4f }, { "c2_aR", 0.4f },
                { "at_pitch", 1.0f }, { "at_bril", 0.7f }, { "glide", 0.08f },
                { "sub_vco", 0.3f }, { "sub_delay", 0.5f }, { "sub_rate", 5.5f }, { "ch_mix", 0.25f } } },

            { "Glass Bells", {
                { "c1_saw", 0 }, { "c1_sine", 1 }, { "c2_saw", 0 }, { "c2_square", 0 }, { "c2_sine", 1 }, { "c2_feet", 3 },
                { "c1_lpf", 12000 }, { "c2_lpf", 12000 }, { "c1_fAmt", 0 }, { "c2_fAmt", 0 },
                { "c1_aA", 0.002f }, { "c2_aA", 0.002f }, { "c1_aD", 2.5f }, { "c2_aD", 1.2f },
                { "c1_aS", 0 }, { "c2_aS", 0 }, { "c1_aR", 2.0f }, { "c2_aR", 1.5f }, { "c2_level", 0.5f },
                { "ring_depth", 0.85f }, { "ring_speed", 680 }, { "ring_attack", 0.005f }, { "ring_decay", 2.0f },
                { "ch_mix", 0.4f } } },

            { "Deep Sub Bass", {
                { "c1_saw", 0 }, { "c1_square", 1 }, { "c1_feet", 0 }, { "c2_feet", 0 }, { "c2_saw", 1 }, { "c2_square", 0 },
                { "c2_detune", 4 }, { "c1_lpf", 250 }, { "c2_lpf", 280 }, { "c1_lpfRes", 0.3f }, { "c2_lpfRes", 0.3f },
                { "c1_fAmt", 0.4f }, { "c2_fAmt", 0.4f }, { "c1_fD", 0.4f }, { "c2_fD", 0.4f },
                { "c1_aS", 1 }, { "c2_aS", 1 }, { "c1_aR", 0.2f }, { "c2_aR", 0.2f }, { "ch_mix", 0 }, { "drift", 0.15f } } },

            { "Warm Strings", {
                { "c2_saw", 1 }, { "c2_square", 0 }, { "c2_feet", 2 }, { "c2_detune", 5 }, { "c2_level", 0.55f },
                { "c1_hpf", 180 }, { "c2_hpf", 250 }, { "c1_lpf", 2500 }, { "c2_lpf", 3000 },
                { "c1_lpfRes", 0 }, { "c2_lpfRes", 0 }, { "c1_fAmt", 0.15f }, { "c2_fAmt", 0.15f },
                { "c1_aA", 0.6f }, { "c2_aA", 0.7f }, { "c1_aS", 1 }, { "c2_aS", 1 }, { "c1_aR", 1.5f }, { "c2_aR", 1.6f },
                { "sub_vco", 0.08f }, { "sub_delay", 1.0f },
                { "ch_mix", 0.7f }, { "ch_depth", 0.8f }, { "ch_rate", 0.6f } } },
        };
        return list;
    }
}

Paragon8AudioProcessor::Paragon8AudioProcessor()
    : AudioProcessor (BusesProperties().withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMS", createParameterLayout())
{
    ptrs.init (apvts);
    ptrs.load (params);

    synth.addSound (new Paragon8Sound());
    for (int i = 0; i < 8; ++i)                           // 8 voices, just like the original
        synth.addVoice (new Paragon8Voice (params, lfoBuffer, lastFreq, 1234 + i * 977));
    synth.setNoteStealingEnabled (true);
}

bool Paragon8AudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    return out == juce::AudioChannelSet::stereo() || out == juce::AudioChannelSet::mono();
}

void Paragon8AudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    synth.setCurrentPlaybackSampleRate (sampleRate);
    lfoBuffer.assign ((size_t) std::max (1, samplesPerBlock), 0.0f);
    chorus.prepare (sampleRate);
    gain.reset (sampleRate, 0.05);
    gain.setCurrentAndTargetValue (juce::Decibels::decibelsToGain (ptrs.volume->load()));
}

void Paragon8AudioProcessor::fillLfo (int n)
{
    if ((int) lfoBuffer.size() < n)
        lfoBuffer.resize ((size_t) n, 0.0f);   // only happens if the host lies about block size

    const float sr = (float) getSampleRate();
    const float inc = params.subRate / sr;
    const float noiseCoef = 1.0f - std::exp (-p8::twoPi * params.subRate * 4.0f / sr);

    for (int i = 0; i < n; ++i)
    {
        lfoPhase += inc;
        if (lfoPhase >= 1.0f) { lfoPhase -= 1.0f; lfoHeld = rng.nextFloat() * 2.0f - 1.0f; }

        float v = 0;
        switch (params.subWave)
        {
            case 0: v = std::sin (p8::twoPi * lfoPhase); break;
            case 1: v = lfoPhase < 0.5f ? 1.0f : -1.0f; break;
            case 2: v = 2.0f * lfoPhase - 1.0f; break;
            case 3: v = 1.0f - 2.0f * lfoPhase; break;
            case 4: v = lfoHeld; break;
            default: lfoNoise += ((rng.nextFloat() * 2.0f - 1.0f) - lfoNoise) * noiseCoef; v = juce::jlimit (-1.0f, 1.0f, lfoNoise * 3.0f); break;
        }
        lfoBuffer[(size_t) i] = v;
    }
}

void Paragon8AudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();

    const int n = buffer.getNumSamples();
    ptrs.load (params);
    fillLfo (n);

    synth.renderNextBlock (buffer, midi, 0, n);

    float* L = buffer.getWritePointer (0);
    float* R = buffer.getNumChannels() > 1 ? buffer.getWritePointer (1) : nullptr;

    const float mix = ptrs.chMix->load();
    if (mix > 0.001f)
        chorus.process (L, R, n, ptrs.chRate->load(), ptrs.chDepth->load(), mix);

    gain.setTargetValue (juce::Decibels::decibelsToGain (ptrs.volume->load()));
    for (int i = 0; i < n; ++i)
    {
        const float g = gain.getNextValue();
        L[i] *= g;
        if (R != nullptr) R[i] *= g;
    }
}

juce::AudioProcessorEditor* Paragon8AudioProcessor::createEditor() { return new Paragon8AudioProcessorEditor (*this); }

int Paragon8AudioProcessor::getNumPrograms() { return (int) presets().size(); }

const juce::String Paragon8AudioProcessor::getProgramName (int index)
{
    return juce::isPositiveAndBelow (index, (int) presets().size()) ? presets()[(size_t) index].name : "";
}

void Paragon8AudioProcessor::setCurrentProgram (int index)
{
    if (! juce::isPositiveAndBelow (index, (int) presets().size()))
        return;

    currentProgram = index;

    for (auto* p : getParameters())
        if (auto* rp = dynamic_cast<juce::RangedAudioParameter*> (p))
            rp->setValueNotifyingHost (rp->getDefaultValue());

    for (auto& [id, value] : presets()[(size_t) index].values)
        if (auto* rp = apvts.getParameter (id))
            rp->setValueNotifyingHost (rp->convertTo0to1 (value));
}

void Paragon8AudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    state.setProperty ("program", currentProgram, nullptr);
    if (auto xml = state.createXml())
        copyXmlToBinary (*xml, destData);
}

void Paragon8AudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType()))
        {
            auto tree = juce::ValueTree::fromXml (*xml);
            currentProgram = tree.getProperty ("program", 0);
            apvts.replaceState (tree);
        }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new Paragon8AudioProcessor(); }
