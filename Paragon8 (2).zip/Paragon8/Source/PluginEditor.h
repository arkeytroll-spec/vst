#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"

class KnobLook : public juce::LookAndFeel_V4
{
public:
    KnobLook();
    void drawRotarySlider (juce::Graphics&, int x, int y, int w, int h, float pos,
                           float startAngle, float endAngle, juce::Slider&) override;
};

class Paragon8AudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit Paragon8AudioProcessorEditor (Paragon8AudioProcessor&);
    ~Paragon8AudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    struct Cell { const char* id; const char* label; };
    struct Row
    {
        juce::String title;
        juce::Colour colour;
        std::vector<Cell> cells;
        juce::Rectangle<int> area;
    };

    struct Control
    {
        int row = 0, col = 0;
        std::unique_ptr<juce::Slider> slider;
        std::unique_ptr<juce::ComboBox> combo;
        std::unique_ptr<juce::Label> label;
        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> sliderAttachment;
        std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> comboAttachment;
    };

    Paragon8AudioProcessor& proc;
    KnobLook look;
    std::vector<Row> rows;
    std::vector<std::unique_ptr<Control>> controls;
    juce::ComboBox presetBox;

    static constexpr int maxColumns = 13;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (Paragon8AudioProcessorEditor)
};
