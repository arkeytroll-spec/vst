#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "Params.h"
#include "SynthVoice.h"

// Stereo BBD-style chorus that turns the mono voice bus into a wide stereo image.
struct StereoChorus
{
    std::vector<float> buf;
    int write = 0;
    float phase = 0;
    double sr = 44100;

    void prepare (double sampleRate)
    {
        sr = sampleRate;
        buf.assign ((size_t) (sr * 0.05) + 4, 0.0f);
        write = 0;
    }

    float read (float delaySamples) const
    {
        const int size = (int) buf.size();
        float pos = (float) write - delaySamples;
        while (pos < 0) pos += (float) size;
        const int i0 = (int) pos;
        const int i1 = (i0 + 1) % size;
        const float frac = pos - (float) i0;
        return buf[(size_t) i0] + (buf[(size_t) i1] - buf[(size_t) i0]) * frac;
    }

    void process (float* L, float* R, int n, float rate, float depth, float mix)
    {
        if (buf.empty()) return;
        const float fsr = (float) sr;
        for (int i = 0; i < n; ++i)
        {
            const float in = R != nullptr ? 0.5f * (L[i] + R[i]) : L[i];
            buf[(size_t) write] = in;

            phase += rate / fsr;
            if (phase >= 1.0f) phase -= 1.0f;
            const float mL = std::sin (p8::twoPi * phase);
            const float mR = std::sin (p8::twoPi * (phase + 0.25f));
            const float base = 0.007f * fsr, span = depth * 0.0045f * fsr;

            const float wetL = read (base + span * (1.0f + mL));
            const float wetR = read (base + span * (1.0f + mR));

            if (++write >= (int) buf.size()) write = 0;

            L[i] = L[i] * (1.0f - mix * 0.5f) + wetL * mix;
            if (R != nullptr) R[i] = R[i] * (1.0f - mix * 0.5f) + wetR * mix;
        }
    }
};

class Paragon8AudioProcessor : public juce::AudioProcessor
{
public:
    Paragon8AudioProcessor();
    ~Paragon8AudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "Paragon-8"; }
    bool acceptsMidi() const override  { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 5.0; }

    int getNumPrograms() override;
    int getCurrentProgram() override { return currentProgram; }
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState apvts;

private:
    void fillLfo (int numSamples);

    ParamPointers ptrs;
    SynthParams params;
    juce::Synthesiser synth;
    std::vector<float> lfoBuffer;
    float lastFreq = 0.0f;

    float lfoPhase = 0, lfoHeld = 0, lfoNoise = 0;
    juce::Random rng;

    StereoChorus chorus;
    juce::SmoothedValue<float> gain;
    int currentProgram = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (Paragon8AudioProcessor)
};
