#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include <cmath>
#include "Params.h"

namespace p8
{
    constexpr float twoPi = 6.28318530718f;

    // Band-limits the saw/pulse edges so high notes don't alias.
    inline float polyBlep (float t, float dt)
    {
        if (t < dt)         { t /= dt;               return t + t - t * t - 1.0f; }
        if (t > 1.0f - dt)  { t = (t - 1.0f) / dt;   return t * t + t + t + 1.0f; }
        return 0.0f;
    }

    // Zero-delay-feedback 12 dB/oct state-variable filter (one per HPF and LPF, like the original's pair).
    struct SVF
    {
        float ic1 = 0, ic2 = 0;
        void reset() { ic1 = ic2 = 0; }
        void process (float v0, float g, float k, float& lp, float& hp)
        {
            const float a1 = 1.0f / (1.0f + g * (g + k));
            const float a2 = g * a1, a3 = g * a2;
            const float v3 = v0 - ic2;
            const float v1 = a1 * ic1 + a2 * v3;
            const float v2 = ic2 + a2 * ic1 + a3 * v3;
            ic1 = 2.0f * v1 - ic1;
            ic2 = 2.0f * v2 - ic2;
            lp = v2;
            hp = v0 - k * v1 - v2;
        }
    };

    inline float coefFor (float seconds, double sr) { return 1.0f - std::exp (-5.0f / (float) (std::max (0.001f, seconds) * sr)); }

    struct AmpEnv
    {
        enum Stage { Idle, Attack, Decay, Sustain, Release } stage = Idle;
        float v = 0, attInc = 0, decCoef = 0, relCoef = 0, sus = 1;

        void set (float a, float d, float s, float r, double sr)
        {
            attInc = 1.0f / (float) (std::max (0.001f, a) * sr);
            decCoef = coefFor (d, sr);
            relCoef = coefFor (r, sr);
            sus = s;
        }
        void noteOn()  { stage = Attack; }             // attacks from wherever it is (no clicks on retrigger)
        void noteOff() { if (stage != Idle) stage = Release; }
        void reset()   { stage = Idle; v = 0; }
        bool active() const { return stage != Idle; }

        float next()
        {
            switch (stage)
            {
                case Attack:  v += attInc; if (v >= 1.0f) { v = 1.0f; stage = Decay; } break;
                case Decay:   v += (sus - v) * decCoef; if (std::abs (v - sus) < 1.0e-4f) stage = Sustain; break;
                case Sustain: v += (sus - v) * decCoef; break;
                case Release: v -= v * relCoef; if (v < 1.0e-5f) { v = 0; stage = Idle; } break;
                case Idle:    default: break;
            }
            return v;
        }
    };

    // Filter EG in the classic IL / AL style: starts at Initial Level, moves to Attack Level,
    // decays back to the knob's base cutoff, and on release returns to Initial Level.
    struct FilterEnv
    {
        enum Stage { Idle, Attack, Decay, Release } stage = Idle;
        float v = 0, il = 0, al = 1, attInc = 0, decCoef = 0, relCoef = 0, pos = 0;

        void set (float initL, float attL, float a, float d, float r, double sr)
        {
            il = initL; al = attL;
            attInc = 1.0f / (float) (std::max (0.001f, a) * sr);
            decCoef = coefFor (d, sr);
            relCoef = coefFor (r, sr);
        }
        void noteOn()  { stage = Attack; pos = 0; }
        void noteOff() { if (stage != Idle) stage = Release; }
        void reset()   { stage = Idle; v = 0; pos = 0; }

        float next()
        {
            switch (stage)
            {
                case Attack:  pos += attInc; if (pos >= 1.0f) { pos = 1.0f; stage = Decay; }
                              v = il + (al - il) * pos; break;
                case Decay:   v -= v * decCoef; break;
                case Release: v += (il - v) * relCoef; break;
                case Idle:    default: break;
            }
            return v;
        }
    };
}

struct Paragon8Sound : public juce::SynthesiserSound
{
    bool appliesToNote (int) override    { return true; }
    bool appliesToChannel (int) override { return true; }
};

class Paragon8Voice : public juce::SynthesiserVoice
{
public:
    Paragon8Voice (const SynthParams& p, const std::vector<float>& lfoBuffer, float& sharedLastFreq, int seed)
        : params (p), lfo (lfoBuffer), lastFreq (sharedLastFreq), rng (seed)
    {
        driftPhase = rng.nextFloat();
        driftRate = 0.15f + 0.3f * rng.nextFloat();
    }

    bool canPlaySound (juce::SynthesiserSound* s) override { return dynamic_cast<Paragon8Sound*> (s) != nullptr; }

    void startNote (int midiNote, float velocity, juce::SynthesiserSound*, int pitchWheel) override
    {
        const bool wasIdle = ! chan[0].amp.active() && ! chan[1].amp.active();

        target = (float) juce::MidiMessage::getMidiNoteInHertz (midiNote);
        current = (params.glide > 0.0005f && lastFreq > 0.0f) ? lastFreq : target;
        lastFreq = target;

        vel = velocity;
        polyAT = 0;
        bend = (float) (pitchWheel - 8192) / 8192.0f;
        driftOffset = rng.nextFloat() * 2.0f - 1.0f;
        timeOn = 0;
        ringStage = 0;
        if (wasIdle) ringV = 0;

        for (auto& c : chan)
        {
            if (wasIdle)
            {
                c.hp.reset(); c.lp.reset();
                c.phase = rng.nextFloat();      // free-running analog oscillators
                c.amp.reset(); c.filt.reset();
            }
            c.amp.noteOn();
            c.filt.noteOn();
        }
    }

    void stopNote (float, bool allowTailOff) override
    {
        if (allowTailOff)
        {
            for (auto& c : chan) { c.amp.noteOff(); c.filt.noteOff(); }
        }
        else
        {
            for (auto& c : chan) { c.amp.reset(); c.filt.reset(); }
            clearCurrentNote();
        }
    }

    void pitchWheelMoved (int v) override             { bend = (float) (v - 8192) / 8192.0f; }
    void controllerMoved (int cc, int v) override     { if (cc == 1) modWheel = (float) v / 127.0f; }
    void aftertouchChanged (int v) override           { polyAT = (float) v / 127.0f; }
    void channelPressureChanged (int v) override      { chanAT = (float) v / 127.0f; }

    void renderNextBlock (juce::AudioBuffer<float>& out, int start, int num) override
    {
        if (! isVoiceActive())
            return;

        const double sr = getSampleRate();
        const float fsr = (float) sr;
        const float nyq = fsr * 0.45f;
        const float piOverSr = juce::MathConstants<float>::pi / fsr;

        for (int c = 0; c < 2; ++c)
        {
            const auto& cp = params.ch[c];
            chan[c].amp.set (cp.aA, cp.aD, cp.aS, cp.aR, sr);
            chan[c].filt.set (cp.fIL, cp.fAL, cp.fA, cp.fD, cp.fR, sr);
        }

        const float glideCoef = params.glide > 0.0005f ? 1.0f - std::exp (-1.0f / (params.glide * fsr * 0.3f)) : 1.0f;
        const float ringAttInc = 1.0f / (std::max (0.001f, params.ringAttack) * fsr);
        const float ringDecCoef = params.ringDecay >= 9.99f ? 0.0f : p8::coefFor (params.ringDecay, sr);
        const float delaySamples = params.subDelay * fsr;
        const float at = std::max (polyAT, chanAT);
        const float balGain[2] = { std::min (1.0f, 2.0f * (1.0f - params.balance)),
                                   std::min (1.0f, 2.0f * params.balance) };
        const float velLevelGain = 1.0f - params.velLevel * (1.0f - vel);
        const float atLevelGain = 1.0f + params.atLevel * at * 0.8f;
        const float velOct = (vel - 0.6f) * params.velBril * 5.0f;
        const float staticOct = velOct + at * params.atBril * 3.0f + params.brilliance * 3.0f;
        const float vibDepth = params.subVco + modWheel * 0.6f;

        for (int i = 0; i < num; ++i)
        {
            current += (target - current) * glideCoef;

            const float fade = delaySamples > 1.0f ? std::min (1.0f, timeOn / delaySamples) : 1.0f;
            const int li = start + i;
            const float lfoV = (li < (int) lfo.size() ? lfo[(size_t) li] : 0.0f) * fade;
            timeOn += 1.0f;

            driftPhase += driftRate / fsr;
            if (driftPhase >= 1.0f) driftPhase -= 1.0f;
            const float driftCents = params.drift * (driftOffset * 6.0f + 2.5f * std::sin (p8::twoPi * driftPhase));

            const float semis = bend * params.bendRange + lfoV * vibDepth + at * params.atPitch + driftCents * 0.01f;
            const float keyTrackOct = 0.5f * std::log2 (current / 261.63f);

            float mix = 0.0f;

            for (int c = 0; c < 2; ++c)
            {
                auto& st = chan[c];
                const auto& cp = params.ch[c];

                const float fe = st.filt.next();
                const float ae = st.amp.next();

                const float octave = (float) (cp.feet - 1);
                const float freq = std::min (nyq, current * std::exp2 (octave + (semis + cp.detune * 0.01f) / 12.0f));
                const float dt = freq / fsr;

                st.phase += dt;
                if (st.phase >= 1.0f) st.phase -= 1.0f;
                const float t = st.phase;

                st.pwmPhase += cp.pwmRate / fsr;
                if (st.pwmPhase >= 1.0f) st.pwmPhase -= 1.0f;
                const float pw = juce::jlimit (0.03f, 0.97f, cp.pw + cp.pwmDepth * 0.45f * std::sin (p8::twoPi * st.pwmPhase));

                float osc = 0.0f;
                if (cp.saw > 0.0f)
                    osc += cp.saw * ((2.0f * t - 1.0f) - p8::polyBlep (t, dt));
                if (cp.square > 0.0f)
                {
                    float t2 = t + 1.0f - pw;
                    if (t2 >= 1.0f) t2 -= 1.0f;
                    const float sq = (t < pw ? 1.0f : -1.0f) + p8::polyBlep (t, dt) - p8::polyBlep (t2, dt) - (2.0f * pw - 1.0f);
                    osc += cp.square * sq;
                }
                if (cp.sine > 0.0f)
                    osc += cp.sine * std::sin (p8::twoPi * t);
                if (cp.noise > 0.0f)
                    osc += cp.noise * (rng.nextFloat() * 2.0f - 1.0f);

                const float oct = fe * cp.fAmt * 7.0f + lfoV * params.subVcf + staticOct + keyTrackOct;
                const float lpHz = juce::jlimit (20.0f, nyq, cp.lpf * std::exp2 (oct));
                const float hpHz = juce::jlimit (10.0f, nyq, cp.hpf * std::exp2 (0.5f * oct));

                const float lpK = 2.0f - 2.0f * juce::jlimit (0.0f, 0.97f, cp.lpfRes + params.resonance * 0.5f);
                const float hpK = 2.0f - 2.0f * juce::jlimit (0.0f, 0.97f, cp.hpfRes);

                const float x = std::tanh (osc * 0.8f);   // gentle analog drive
                float lpOut, hpOut, dummy;
                st.hp.process (x, std::tan (hpHz * piOverSr), hpK, dummy, hpOut);
                st.lp.process (hpOut, std::tan (lpHz * piOverSr), lpK, lpOut, dummy);

                const float trem = 1.0f - params.subVca * (0.5f - 0.5f * lfoV);
                mix += lpOut * ae * cp.level * balGain[c] * trem;
            }

            // Ring modulator with its own attack/decay depth envelope
            if (params.ringDepth > 0.0f)
            {
                if (ringStage == 0) { ringV += ringAttInc; if (ringV >= 1.0f) { ringV = 1.0f; ringStage = 1; } }
                else                  ringV -= ringV * ringDecCoef;
                ringPhase += params.ringSpeed / fsr;
                if (ringPhase >= 1.0f) ringPhase -= 1.0f;
                const float d = params.ringDepth * ringV;
                mix *= (1.0f - d) + d * std::sin (p8::twoPi * ringPhase);
            }

            const float s = mix * velLevelGain * atLevelGain * 0.22f;
            for (int ch = 0; ch < out.getNumChannels(); ++ch)
                out.addSample (ch, li, s);

            if (! chan[0].amp.active() && ! chan[1].amp.active())
            {
                clearCurrentNote();
                break;
            }
        }
    }

private:
    struct ChannelState
    {
        float phase = 0, pwmPhase = 0;
        p8::SVF hp, lp;
        p8::AmpEnv amp;
        p8::FilterEnv filt;
    } chan[2];

    const SynthParams& params;
    const std::vector<float>& lfo;
    float& lastFreq;
    juce::Random rng;

    float target = 440, current = 440, vel = 1, bend = 0, modWheel = 0, polyAT = 0, chanAT = 0;
    float timeOn = 0, driftOffset = 0, driftPhase = 0, driftRate = 0.2f;
    float ringPhase = 0, ringV = 0;
    int ringStage = 0;
};
