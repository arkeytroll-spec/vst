#include "PluginEditor.h"

using namespace juce;

namespace Col
{
    const Colour bg      (0xff131519);
    const Colour panel   (0xff1d2026);
    const Colour edge    (0xff2c3038);
    const Colour text    (0xffd8dbe0);
    const Colour dim     (0xff8a909a);
    const Colour amber   (0xffffa53c);
    const Colour teal    (0xff3cd6c4);
    const Colour violet  (0xffa77bff);
    const Colour rose    (0xffff5d7a);
}

KnobLook::KnobLook()
{
    setColour (ComboBox::backgroundColourId, Colour (0xff262a31));
    setColour (ComboBox::outlineColourId, Col::edge);
    setColour (ComboBox::textColourId, Col::text);
    setColour (ComboBox::arrowColourId, Col::dim);
    setColour (PopupMenu::backgroundColourId, Colour (0xff22252b));
    setColour (PopupMenu::textColourId, Col::text);
    setColour (PopupMenu::highlightedBackgroundColourId, Colour (0xff3a3f48));
    setColour (BubbleComponent::backgroundColourId, Colour (0xff262a31));
    setColour (BubbleComponent::outlineColourId, Col::edge);
    setColour (TooltipWindow::textColourId, Col::text);
}

void KnobLook::drawRotarySlider (Graphics& g, int x, int y, int w, int h, float pos,
                                 float startAngle, float endAngle, Slider& s)
{
    const auto accent = s.findColour (Slider::rotarySliderFillColourId);
    const float r = (float) jmin (w, h) * 0.5f - 3.0f;
    const float cx = (float) x + (float) w * 0.5f, cy = (float) y + (float) h * 0.5f;
    const float angle = startAngle + pos * (endAngle - startAngle);

    Path track;
    track.addCentredArc (cx, cy, r, r, 0.0f, startAngle, endAngle, true);
    g.setColour (Colour (0xff2b2f37));
    g.strokePath (track, PathStrokeType (3.0f, PathStrokeType::curved, PathStrokeType::rounded));

    Path value;
    value.addCentredArc (cx, cy, r, r, 0.0f, startAngle, angle, true);
    g.setColour (accent);
    g.strokePath (value, PathStrokeType (3.0f, PathStrokeType::curved, PathStrokeType::rounded));

    const float br = r * 0.7f;
    g.setGradientFill (ColourGradient (Colour (0xff4b515b), cx, cy - br, Colour (0xff1a1c20), cx, cy + br, false));
    g.fillEllipse (cx - br, cy - br, br * 2.0f, br * 2.0f);
    g.setColour (Colours::black.withAlpha (0.6f));
    g.drawEllipse (cx - br, cy - br, br * 2.0f, br * 2.0f, 1.0f);

    Path pointer;
    pointer.addRoundedRectangle (-1.25f, -br + 2.5f, 2.5f, br * 0.55f, 1.2f);
    pointer.applyTransform (AffineTransform::rotation (angle).translated (cx, cy));
    g.setColour (Colours::white.withAlpha (0.92f));
    g.fillPath (pointer);
}

Paragon8AudioProcessorEditor::Paragon8AudioProcessorEditor (Paragon8AudioProcessor& p)
    : AudioProcessorEditor (&p), proc (p)
{
    setLookAndFeel (&look);

    rows =
    {
        { "CHANNEL I  /  OSCILLATOR + FILTERS", Col::amber, {
            { "c1_feet", "FEET" }, { "c1_detune", "DETUNE" }, { "c1_pw", "PW" }, { "c1_pwmRate", "PWM SPD" },
            { "c1_pwmDepth", "PWM AMT" }, { "c1_saw", "SAW" }, { "c1_square", "SQUARE" }, { "c1_sine", "SINE" },
            { "c1_noise", "NOISE" }, { "c1_hpf", "HPF" }, { "c1_hpfRes", "HPF RES" }, { "c1_lpf", "LPF" }, { "c1_lpfRes", "LPF RES" } } },
        { "CHANNEL I  /  ENVELOPES", Col::amber, {
            { "c1_fIL", "F  IL" }, { "c1_fAL", "F  AL" }, { "c1_fA", "F  ATK" }, { "c1_fD", "F  DEC" }, { "c1_fR", "F  REL" },
            { "c1_fAmt", "F  AMT" }, { "c1_aA", "A  ATK" }, { "c1_aD", "A  DEC" }, { "c1_aS", "A  SUS" }, { "c1_aR", "A  REL" },
            { "c1_level", "LEVEL" } } },
        { "CHANNEL II  /  OSCILLATOR + FILTERS", Col::teal, {
            { "c2_feet", "FEET" }, { "c2_detune", "DETUNE" }, { "c2_pw", "PW" }, { "c2_pwmRate", "PWM SPD" },
            { "c2_pwmDepth", "PWM AMT" }, { "c2_saw", "SAW" }, { "c2_square", "SQUARE" }, { "c2_sine", "SINE" },
            { "c2_noise", "NOISE" }, { "c2_hpf", "HPF" }, { "c2_hpfRes", "HPF RES" }, { "c2_lpf", "LPF" }, { "c2_lpfRes", "LPF RES" } } },
        { "CHANNEL II  /  ENVELOPES", Col::teal, {
            { "c2_fIL", "F  IL" }, { "c2_fAL", "F  AL" }, { "c2_fA", "F  ATK" }, { "c2_fD", "F  DEC" }, { "c2_fR", "F  REL" },
            { "c2_fAmt", "F  AMT" }, { "c2_aA", "A  ATK" }, { "c2_aD", "A  DEC" }, { "c2_aS", "A  SUS" }, { "c2_aR", "A  REL" },
            { "c2_level", "LEVEL" } } },
        { "SUB OSCILLATOR  /  RING MOD  /  CHORUS", Col::violet, {
            { "sub_wave", "WAVE" }, { "sub_rate", "SPEED" }, { "sub_delay", "DELAY" }, { "sub_vco", "> PITCH" },
            { "sub_vcf", "> FILTER" }, { "sub_vca", "> AMP" }, { "ring_speed", "RING SPD" }, { "ring_depth", "RING AMT" },
            { "ring_attack", "RING ATK" }, { "ring_decay", "RING DEC" }, { "ch_rate", "CHO SPD" }, { "ch_depth", "CHO DEPTH" },
            { "ch_mix", "CHO MIX" } } },
        { "TOUCH  /  PERFORMANCE  /  OUTPUT", Col::rose, {
            { "vel_bril", "VEL BRIL" }, { "vel_level", "VEL LVL" }, { "at_bril", "AT BRIL" }, { "at_level", "AT LVL" },
            { "at_pitch", "AT PITCH" }, { "bend_range", "RIBBON" }, { "glide", "GLIDE" }, { "drift", "DRIFT" },
            { "brilliance", "BRILLIANCE" }, { "resonance", "RESONANCE" }, { "balance", "I  /  II" }, { "volume", "VOLUME" } } },
    };

    for (int r = 0; r < (int) rows.size(); ++r)
    {
        for (int c = 0; c < (int) rows[(size_t) r].cells.size(); ++c)
        {
            const auto& cell = rows[(size_t) r].cells[(size_t) c];
            auto* param = proc.apvts.getParameter (cell.id);
            jassert (param != nullptr);
            if (param == nullptr) continue;

            auto ctl = std::make_unique<Control>();
            ctl->row = r; ctl->col = c;

            if (auto* choice = dynamic_cast<AudioParameterChoice*> (param))
            {
                ctl->combo = std::make_unique<ComboBox>();
                ctl->combo->addItemList (choice->choices, 1);
                addAndMakeVisible (*ctl->combo);
                ctl->comboAttachment = std::make_unique<AudioProcessorValueTreeState::ComboBoxAttachment> (proc.apvts, cell.id, *ctl->combo);
            }
            else
            {
                ctl->slider = std::make_unique<Slider> (Slider::RotaryHorizontalVerticalDrag, Slider::NoTextBox);
                ctl->slider->setColour (Slider::rotarySliderFillColourId, rows[(size_t) r].colour);
                ctl->slider->setPopupDisplayEnabled (true, true, this);
                addAndMakeVisible (*ctl->slider);
                ctl->sliderAttachment = std::make_unique<AudioProcessorValueTreeState::SliderAttachment> (proc.apvts, cell.id, *ctl->slider);
                ctl->slider->setDoubleClickReturnValue (true, param->convertFrom0to1 (param->getDefaultValue()));
                ctl->slider->setTooltip (param->getName (64));
            }

            ctl->label = std::make_unique<Label> (String(), cell.label);
            ctl->label->setJustificationType (Justification::centred);
            ctl->label->setFont (Font (FontOptions (10.5f, Font::bold)));
            ctl->label->setColour (Label::textColourId, Col::dim);
            ctl->label->setInterceptsMouseClicks (false, false);
            addAndMakeVisible (*ctl->label);

            controls.push_back (std::move (ctl));
        }
    }

    for (int i = 0; i < proc.getNumPrograms(); ++i)
        presetBox.addItem (proc.getProgramName (i), i + 1);
    presetBox.setSelectedId (proc.getCurrentProgram() + 1, dontSendNotification);
    presetBox.onChange = [this] { proc.setCurrentProgram (presetBox.getSelectedId() - 1); };
    addAndMakeVisible (presetBox);

    setSize (1100, 680);
}

Paragon8AudioProcessorEditor::~Paragon8AudioProcessorEditor()
{
    controls.clear();
    setLookAndFeel (nullptr);
}

void Paragon8AudioProcessorEditor::paint (Graphics& g)
{
    g.setGradientFill (ColourGradient (Colour (0xff181b20), 0, 0, Col::bg, 0, (float) getHeight(), false));
    g.fillAll();

    // Header
    g.setColour (Col::text);
    g.setFont (Font (FontOptions (28.0f, Font::bold)));
    g.drawText ("PARAGON-8", 22, 14, 300, 34, Justification::centredLeft);
    g.setColour (Col::dim);
    g.setFont (Font (FontOptions (11.5f)));
    g.drawText ("8-VOICE  DUAL-LAYER  POLYPHONIC  SYNTHESIZER", 190, 14, 420, 34, Justification::centredLeft);

    // Little colour bar under the title
    const Colour stripe[] = { Col::amber, Col::teal, Col::violet, Col::rose };
    for (int i = 0; i < 4; ++i)
    {
        g.setColour (stripe[i]);
        g.fillRect (22 + i * 40, 52, 36, 3);
    }

    g.setColour (Col::dim);
    g.setFont (Font (FontOptions (11.0f, Font::bold)));
    g.drawText ("PRESET", presetBox.getX() - 64, presetBox.getY(), 58, presetBox.getHeight(), Justification::centredRight);

    for (auto& row : rows)
    {
        auto a = row.area.toFloat();
        g.setColour (Col::panel);
        g.fillRoundedRectangle (a, 6.0f);
        g.setColour (Col::edge);
        g.drawRoundedRectangle (a.reduced (0.5f), 6.0f, 1.0f);

        g.setColour (row.colour);
        g.fillRoundedRectangle (a.getX() + 8, a.getY() + 8, 4, 11, 1.5f);
        g.setFont (Font (FontOptions (11.0f, Font::bold)));
        g.drawText (row.title, (int) a.getX() + 18, (int) a.getY() + 4, 500, 18, Justification::centredLeft);
    }
}

void Paragon8AudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced (16, 12);
    auto top = area.removeFromTop (48);
    presetBox.setBounds (top.removeFromRight (240).withSizeKeepingCentre (240, 28));
    area.removeFromTop (6);

    const int rowH = area.getHeight() / (int) rows.size();
    for (auto& row : rows)
        row.area = area.removeFromTop (rowH).reduced (0, 3);

    for (auto& ctl : controls)
    {
        auto ra = rows[(size_t) ctl->row].area.reduced (8, 4);
        ra.removeFromTop (18);
        const int cellW = ra.getWidth() / maxColumns;
        Rectangle<int> cell (ra.getX() + ctl->col * cellW, ra.getY(), cellW, ra.getHeight());

        ctl->label->setBounds (cell.removeFromBottom (15));

        if (ctl->slider != nullptr)
        {
            const int d = jmin (cell.getWidth(), cell.getHeight());
            ctl->slider->setBounds (cell.withSizeKeepingCentre (d, d));
        }
        else if (ctl->combo != nullptr)
        {
            ctl->combo->setBounds (cell.withSizeKeepingCentre (cellW - 10, 24));
        }
    }
}
